/* ===================================================
   Gh0st_Prot0cal - Ultimate Security Engine v6.0
   Full AI Tools + Navigation + Section Animations
=================================================== */


/* ============================
   BASIC TOOLS
============================ */

function analyzeURL() {
    const url = document.getElementById("urlInput")?.value;
    const result = document.getElementById("urlResult");
    if (!url || !result) return;

    let score = 0;
    const input = url.toLowerCase();

    if (input.startsWith("http://")) score += 30;
    if (input.includes("@")) score += 30;
    if (input.includes("bit.ly") || input.includes("tinyurl")) score += 25;
    if (input.includes(".ru") || input.includes(".xyz") || input.includes(".tk")) score += 20;

    if (score > 100) score = 100;

    result.innerHTML = score === 0
        ? "✅ Website appears safe."
        : `⚠ Risk Score: ${score}%`;
}


function checkPassword() {
    const password = document.getElementById("passwordInput")?.value;
    const result = document.getElementById("passwordResult");
    if (!password || !result) return;

    let score = 0;

    if (password.length >= 8) score += 25;
    if (/[A-Z]/.test(password)) score += 25;
    if (/[0-9]/.test(password)) score += 25;
    if (/[^A-Za-z0-9]/.test(password)) score += 25;

    if (score < 50) result.innerHTML = "❌ Weak Password";
    else if (score < 75) result.innerHTML = "⚠ Moderate Password";
    else result.innerHTML = "✅ Strong Password";
}


async function generateHash() {
    const text = document.getElementById("hashInput")?.value;
    const result = document.getElementById("hashResult");
    if (!text || !result) return;

    const buffer = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest("SHA-256", buffer);
    const hex = Array.from(new Uint8Array(hash))
        .map(b => b.toString(16).padStart(2, "0"))
        .join("");

    result.innerHTML = hex;
}


/* ============================
   AI CORE FUNCTIONS
============================ */

function calculateLevel(score) {
    if (score >= 75) return "CRITICAL";
    if (score >= 45) return "HIGH";
    if (score >= 25) return "MEDIUM";
    return "LOW";
}

function addLog(score, level, type) {
    const log = document.getElementById("threatLog");
    if (!log) return;

    const time = new Date().toLocaleTimeString();
    log.innerHTML += `[${time}] ${type} → ${score}% | ${level}\n`;
}


/* ============================
   AI PHISHING INTELLIGENCE
============================ */

function scanPhishing() {
    const inputRaw = document.getElementById("phishingInput")?.value;
    const result = document.getElementById("phishingResult");
    if (!inputRaw || !result) return;

    const input = inputRaw.toLowerCase();
    let score = 0;

    const patterns = [
        /ask(ed)? for.*otp/,
        /ask(ed)? for.*password/,
        /ask(ed)? for.*bank detail/,
        /ask(ed)? for.*login detail/,
        /someone.*ask.*otp/,
        /someone.*ask.*password/
    ];

    patterns.forEach(p => {
        if (p.test(input)) score += 40;
    });

    if (input.includes("urgent")) score += 15;
    if (input.includes("click here")) score += 20;

    if (score > 100) score = 100;

    const level = calculateLevel(score);
    result.innerHTML = `🚨 Threat Score: ${score}% | ${level}`;
    addLog(score, level, "Phishing Scan");
}


/* ============================
   AI SOCIAL ENGINEERING
============================ */

function scanSocialEngineering() {
    const inputRaw = document.getElementById("socialInput")?.value;
    const result = document.getElementById("socialResult");
    if (!inputRaw || !result) return;

    const input = inputRaw.toLowerCase();
    let score = 0;

    const impersonation = [
        "i am from bank",
        "tech support",
        "your boss",
        "admin here",
        "courier service"
    ];

    impersonation.forEach(word => {
        if (input.includes(word)) score += 25;
    });

    if (input.includes("install this app")) score += 25;
    if (input.includes("share screen")) score += 20;

    if (score > 100) score = 100;

    const level = calculateLevel(score);
    result.innerHTML = `🕵 Social Engineering Risk: ${score}% | ${level}`;
    addLog(score, level, "Social Engineering");
}


/* ============================
   AI DATA LEAK SCANNER
============================ */

function scanDataLeak() {
    const inputRaw = document.getElementById("dataInput")?.value;
    const result = document.getElementById("dataResult");
    if (!inputRaw || !result) return;

    let score = 0;

    const creditCard = /\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/;
    const phone = /\b\d{10}\b/;
    const email = /[^\s@]+@[^\s@]+\.[^\s@]+/;
    const password = /password\s*[:=]/i;

    if (creditCard.test(inputRaw)) score += 40;
    if (phone.test(inputRaw)) score += 20;
    if (email.test(inputRaw)) score += 15;
    if (password.test(inputRaw)) score += 30;

    if (score > 100) score = 100;

    const level = calculateLevel(score);
    result.innerHTML = `📂 Data Exposure Risk: ${score}% | ${level}`;
    addLog(score, level, "Data Leak Scan");
}


/* ============================
   STABLE NAVIGATION SYSTEM
============================ */

document.addEventListener("DOMContentLoaded", function () {

    const sections = document.querySelectorAll("section");
    const navLinks = document.querySelectorAll(".nav-link");

    function setActive(id) {
        navLinks.forEach(link => {
            link.classList.remove("active");
            if (link.getAttribute("href") === "#" + id) {
                link.classList.add("active");
            }
        });
    }

    window.addEventListener("scroll", function () {
        let current = "";

        sections.forEach(section => {
            const top = section.offsetTop - 150;
            const height = section.offsetHeight;

            if (window.scrollY >= top &&
                window.scrollY < top + height) {
                current = section.getAttribute("id");
            }
        });

        if (current !== "") setActive(current);
    });


    /* ============================
       SECTION ANIMATION ENGINE
    ============================= */

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("show-section");
            }
        });
    }, { threshold: 0.2 });

    document.querySelectorAll("#about, #learn").forEach(section => {
        observer.observe(section);
    });

});